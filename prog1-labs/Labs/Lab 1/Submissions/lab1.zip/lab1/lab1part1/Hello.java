public class Hello {
	//an error was caused here as I put the square brackets in front of String, rather than args
	public static void main(String[] args){
		//An error was caused here as the L in println was capitalised
		//An error was also caused here because of a missing semicolon at the end
		//this line prints out the message Hellow World!
		System.out.println("Hello World!");
	}
}