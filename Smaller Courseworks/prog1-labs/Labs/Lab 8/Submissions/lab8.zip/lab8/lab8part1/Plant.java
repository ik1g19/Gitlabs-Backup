//the plant class inherits from the food class
//and initialises the plant with a name when it is created
public class Plant extends Food {
    //calls the constructor of the super class and passes the given name to it
    public Plant(String name) {
        super(name);
    }
}