/*
train is a class as it needs to be instantiated, it is not refuelable but is a form of transport,
so it implements transport
 */
public class Train implements Transport{
    //detaches the carriage
    public void detachCarriage() {}


    //implementation to increase and decrease the velocity of the train
    public void increaseVelocity() {}

    public void decreaseVelocity() {}
}
