/*
tricycle is a class as it needs to be instantiated, it is a type of cycle so it inherits from cycle
 */
public class Tricycle extends Cycle{
    //implementation to increase and decrease the velocity of the tricycle
    public void increaseVelocity() {}

    public void decreaseVelocity() {}


    //implementation for replacing the wheels of a tricycle
    public void replaceWheels() {}
}
