/*
bicycle is a class as it needs to be instantiated, it is a type of cycle so it inherits from cycle
 */
public class Bicycle extends Cycle{
    //implementation to increase and decrease the velocity of the bicycle
    public void increaseVelocity() {}

    public void decreaseVelocity() {}


    //implementation for replacing the wheels of a bicycle
    public void replaceWheels() {}
}