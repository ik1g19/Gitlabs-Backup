/*
jetplane is a class as it needs to be instantiated, it is a refuelable form of transport
so it implements refuelable
 */
public class JetPlane implements Refuelable{
    //plane taking off the runway
    public void takeOff() {}


    //implementation for the refueling of the plane
    public void refuel() {}


    //implementation to increase and decrease the velocity of the plane
    public void increaseVelocity() {}

    public void decreaseVelocity() {}
}
