//inherits from animal and is inherited herbivores
public abstract class Herbivore extends Animal {
}
