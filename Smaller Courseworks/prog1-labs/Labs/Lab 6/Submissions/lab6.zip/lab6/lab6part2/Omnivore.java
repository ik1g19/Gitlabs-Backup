//inherits from animal and is inherited omnivores
public abstract class Omnivore extends Animal {
}
