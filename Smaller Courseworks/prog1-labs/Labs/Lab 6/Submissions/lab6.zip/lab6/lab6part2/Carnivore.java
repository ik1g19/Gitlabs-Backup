//inherits from animal and is inherited carnivores
public abstract class Carnivore extends Animal {

}
