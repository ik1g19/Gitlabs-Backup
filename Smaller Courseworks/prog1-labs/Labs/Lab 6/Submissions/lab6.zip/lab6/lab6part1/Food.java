//the food class contains the name of the food and the getter for the name
public class Food {
    private String name;

    //initialises the name of the food with the given variable
    public Food(String name) {
        this.name = name;
    }

    //returns the name of the food
    public String getName() {
        return name;
    }
}
