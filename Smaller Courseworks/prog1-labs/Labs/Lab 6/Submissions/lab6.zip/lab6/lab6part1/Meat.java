//the meat class inherits from the food class
//and initialises the meat with a name when the object is created
public class Meat extends Food {
    //calls the constructor of the super class and passes the given name
    public Meat(String name) {
        super(name);
    }
}